# Feedback Bot made by Developers Support (@iyed)

A Discord bot that generates a stylized image containing feedback messages sent in a specific channel.

## Features
- Automatically captures messages in a designated feedback channel.
- Deletes the original message and replaces it with an image containing the feedback text.
- Includes the user's avatar in the generated image.
- Uses a custom background image.

## Requirements
- [Node.js](https://nodejs.org/) v16.6.0 or higher
- [Discord.js](https://discord.js.org/) v14 or higher
- Canvas library (`npm install canvas`)

## Installation

1. Clone the repository or download the code:
   ```bash
   git clone <repository-url>
   cd <repository-folder>
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Configure the bot:
   - Create a `config.json` file in the root directory with the following structure:
     ```json
     {
       "token": "YOUR_BOT_TOKEN",
       "channel_id": "YOUR_FEEDBACK_CHANNEL_ID"
     }
     ```
   - Replace `YOUR_BOT_TOKEN` with your bot's token and `YOUR_FEEDBACK_CHANNEL_ID` with the channel ID where feedback messages will be captured.

4. Add a background image:
   - Place a custom background image named `back.jpg` in a `system` folder located in the root directory.

## Usage

1. Start the bot:
   ```bash
   node bot.js
   ```

2. Invite the bot to your Discord server with the necessary permissions:
   - `Read Messages`
   - `Send Messages`
   - `Manage Messages`
   - `Attach Files`

3. Send a message in the designated feedback channel, and the bot will replace it with an image containing the feedback.

## Customization

- **Background Image**: Replace `system/back.jpg` with your own image to customize the background.
- **Canvas Dimensions**: Update the canvas size (`Canvas.createCanvas(800, 300)`) in the code to adjust the image dimensions.
- **Font and Colors**: Modify the `ctx.font`, `ctx.fillStyle`, and other drawing properties to customize the text style.

## Troubleshooting

- **Bot is not responding**:
  - Ensure the bot is online.
  - Verify the `channel_id` in `config.json` matches the feedback channel's ID.
- **Canvas-related errors**:
  - Make sure the `canvas` dependency is installed correctly. Some systems may require additional libraries (e.g., `libcairo` for Linux).
  - Refer to the [Canvas installation guide](https://github.com/Automattic/node-canvas#installation).

## License
This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

---

Enjoy using Feedback Bot! 😊