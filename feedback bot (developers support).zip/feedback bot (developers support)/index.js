//dont forget to install discord.js package 'npm i discord.js'
//dont forget to install canvas package (npm i canvas)
//dont forget to install fs package (npm i fs)
//alrights to <Developers Support>

const { Client, GatewayIntentBits, Partials, AttachmentBuilder } = require('discord.js');
const Canvas = require('canvas');

const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
    partials: [Partials.Message, Partials.Channel, Partials.User]
});
const { token ,channel_id } = require('./config.json');

client.once('ready', () => {
    console.log(`
${client.user.username} connected!
- - - - - - - - - - - - - - 
Alrights to <Developers Support>
    `);
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return; 
    if (message.channel.id === channel_id) {

        const feedbackText = message.content;
        await message.delete();

        const canvas = Canvas.createCanvas(800, 300); 
        const ctx = canvas.getContext('2d');
        const background = await Canvas.loadImage('./system/back.jpg');
        ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

    
        const avatarSize = 200; 
        const avatarX = 47; 
        const avatarY = 51; 

        const avatar = await Canvas.loadImage(message.author.displayAvatarURL({ extension: 'png' }));
        ctx.save(); 
        ctx.beginPath();
        ctx.arc(avatarX + avatarSize / 2, avatarY + avatarSize / 2, avatarSize / 2, 0, Math.PI * 2, true); 
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(avatar, avatarX, avatarY, avatarSize, avatarSize);
        ctx.restore();

  
        const textX = 520
        let textY = 120

        ctx.fillStyle = '#373b8a';
        ctx.font = '28px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        const wrapText = (text, maxWidth) => {
            const words = text.split(' ');
            const lines = [];
            let currentLine = words[0];

            for (let i = 1; i < words.length; i++) {
                const word = words[i];
                const width = ctx.measureText(currentLine + ' ' + word).width;
                if (width < maxWidth) {
                    currentLine += ' ' + word;
                } else {
                    lines.push(currentLine);
                    currentLine = word;
                }
            }
            lines.push(currentLine);
            return lines;
        };

        const maxTextWidth = canvas.width - 100; 
        const lines = wrapText(feedbackText, maxTextWidth);
        const lineHeight = 48; 
        textY -= (lines.length / 2) * lineHeight; 

        lines.forEach((line, index) => {
            ctx.fillText(line, textX, textY + index * lineHeight);
        });

      
        const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'feedback.png' });
        message.channel.send({ files: [attachment] });
    } 
});

client.login(token);
